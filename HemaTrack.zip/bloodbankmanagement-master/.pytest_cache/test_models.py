
import pytest
from blood.models import Stock, BloodRequest
from patient.models import Patient
from donor.models import Donor
from django.contrib.auth.models import User 
@pytest.mark.django_db
def test_stock_model():
    stock = Stock.objects.create(bloodgroup="A+", unit=10)
    assert stock.bloodgroup == "A+"
    assert stock.unit == 10

@pytest.mark.django_db
def test_blood_request_model():
    patient = Patient.objects.create(name="John", age=30)
    donor = Donor.objects.create(name="Alice", age=25)
    blood_request = BloodRequest.objects.create(
        request_by_patient=patient,
        request_by_donor=donor,
        patient_name="John",
        patient_age=30,
        reason="Emergency surgery",
        bloodgroup="A+",
        unit=2,
        status="Pending"
    )
    assert blood_request.patient_name == "John"
    assert blood_request.patient_age == 30
    assert blood_request.reason == "Emergency surgery"
    assert blood_request.bloodgroup == "A+"
    assert blood_request.unit == 2
    assert blood_request.status == "Pending"
from donor.models import Donor, BloodDonate

@pytest.mark.django_db
def test_donor_model():
    # Create a user
    user = User.objects.create(username='testuser', first_name='John', last_name='Doe')

    # Create a donor
    donor = Donor.objects.create(
        user=user,
        bloodgroup='A+',
        address='123 Main St',
        mobile='1234567890'
    )

    # Test properties
    assert donor.get_name == 'John Doe'
    assert donor.get_instance == donor
    assert str(donor) == 'John'

@pytest.mark.django_db
def test_blooddonate_model():
    # Create a user
    user = User.objects.create(username='testuser', first_name='Jane', last_name='Smith')

    # Create a donor
    donor = Donor.objects.create(
        user=user,
        bloodgroup='AB-',
        address='456 Elm St',
        mobile='0987654321'
    )

    # Create a blood donation
    blood_donation = BloodDonate.objects.create(
        donor=donor,
        disease='Cold',
        age=30,
        bloodgroup='AB-',
        unit=2,
        status='Pending'
    )

    # Test __str__ method
    assert str(blood_donation) == 'Jane'
from django.contrib.auth.models import User
from patient.models import Patient

@pytest.mark.django_db
def test_patient_model():
    # Create a user
    user = User.objects.create(username='testuser', first_name='Alice', last_name='Doe')

    # Create a patient
    patient = Patient.objects.create(
        user=user,
        age=25,
        bloodgroup='B+',
        disease='Fever',
        doctorname='Dr. Smith',
        address='123 Main St',
        mobile='1234567890'
    )

    # Test properties
    assert patient.get_name == 'Alice Doe'
    assert patient.get_instance == patient
    assert str(patient) == 'Alice'
