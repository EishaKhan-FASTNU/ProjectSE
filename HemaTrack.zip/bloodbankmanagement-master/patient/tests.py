from django.test import TestCase
from django.contrib.auth.models import User
from patient.models import Patient

class PatientModelTestCase(TestCase):
    def setUp(self):
        # Create a user
        self.user = User.objects.create(username='testuser', first_name='Eisha', last_name='Khan')

        # Create a patient
        self.patient = Patient.objects.create(
            user=self.user,
            age=22,
            bloodgroup='B+',
            disease='Fever',
            doctorname='Dr. Eisha',
            address='123 Main St',
            mobile='1234567890'
        )

 
    def test_patient_properties(self):
        # Test properties
      
        self.assertEqual(self.patient.get_name, 'Eisha Kha')


    def test_patient_age(self):
        # Test patient age
        self.assertEqual(self.patient.age, 25)

    def test_patient_bloodgroup(self):
        # Test patient blood group
        self.assertEqual(self.patient.bloodgroup, 'B+')

    def test_patient_disease(self):
        # Test patient disease
        self.assertEqual(self.patient.disease, 'Fever')
    