from django.test import TestCase
from django.contrib.auth.models import User
from patient.models import Patient
from blood.models import BloodRequest

class BloodRequestModelTestCase(TestCase):
    def setUp(self):
        # Create a user for the patient
        self.patient_user = User.objects.create(username='patientuser', first_name='John', last_name='Doe')

        # Create a patient
        self.patient = Patient.objects.create(
            user=self.patient_user,
            age=30,
            bloodgroup='A+',
            disease='Fever',
            doctorname='Dr. Eisha',
            address='123 Main St',
            mobile='1234567890'
        )

    def test_blood_request_model(self):
        # Create a blood request
        blood_request = BloodRequest.objects.create(
            request_by_patient=self.patient,
            patient_age=self.patient.age,
            reason='Emergency surgery',
            bloodgroup='A+',
            unit=2,
            status='Pending'
        )

        # Test the attributes of the blood request
        self.assertEqual(blood_request.request_by_patient, self.patient)
        self.assertEqual(blood_request.patient_age, 30)
        self.assertEqual(blood_request.reason, 'Emergency surgery')
        self.assertEqual(blood_request.bloodgroup, 'A+')
        self.assertEqual(blood_request.unit, 2)
        self.assertEqual(blood_request.status, 'Pending')
