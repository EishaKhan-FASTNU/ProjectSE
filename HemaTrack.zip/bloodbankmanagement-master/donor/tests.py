from django.test import TestCase
from django.contrib.auth.models import User
from donor.models import Donor, BloodDonate

class DonorModelTestCase(TestCase):
    def setUp(self):
        # Create a user
        self.user = User.objects.create(username='testuser', first_name='Eisha', last_name='Imran')

        # Create a donor
        self.donor = Donor.objects.create(
            user=self.user,
            bloodgroup='A+',
            address='123 Main St',
            mobile='1234567890'
        )

    def test_donor_properties(self):
        self.assertEqual(self.donor.get_name, 'John Doe')

class BloodDonateModelTestCase(TestCase):
    def setUp(self):
        # Create a user
        self.user = User.objects.create(username='testuser', first_name='Ali', last_name='Hammad')

        # Create a donor
        self.donor = Donor.objects.create(
            user=self.user,
            bloodgroup='AB-',
            address='456 Elm St',
            mobile='0987654321'
        )

        # Create a blood donation
        self.blood_donation = BloodDonate.objects.create(
            donor=self.donor,
            disease='Cold',
            age=30,
            bloodgroup='AB-',
            unit=2,
            status='Pending'
        )



       
    def test_blooddonate_disease(self):
        # Test the disease attribute of BloodDonate model
        self.assertEqual(self.blood_donation.disease, 'Cold')

    def test_blooddonate_age(self):
        # Test the age attribute of BloodDonate model
        self.assertEqual(self.blood_donation.age, 30)

    def test_blooddonate_status(self):
        # Test the status attribute of BloodDonate model
        self.assertEqual(self.blood_donation.status, 'Pending')

    def test_blooddonate_unit(self):
        # Test the unit attribute of BloodDonate model
        self.assertEqual(self.blood_donation.unit, 2)

